# Reto Don Perro

## Identificar cual de los 3 colores es el que está más cerca (rojo, azul, verde):
* Si el rojo es el más cercano, buscar la pizza
* Si el azul es más cercano, buscar el gato
* Si el verde es el más cercano, buscar la banana

## Moverse cerca de los spotlights para identificar el id
* Por cada spotlight fallido, el robot deberá girar 90 grados al final del recorrido.

> NOTA: El giro final de 90 grados no debe ser perfecto
