#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from vision_msgs.msg import Detection2DArray
import sys

class object_detector:
    def __init__(self):
        self.vel = Twist()
        self.state = 0
        self.count = 0
        self.sheep = 0
        self.color = 0
        self.green = 0
        
        self.detect_sub = rospy.Subscriber("room", Int32, self.actual)
        self.detect_sub = rospy.Subscriber("objects", Detection2DArray, self.callback)
        self.con = rospy.Publisher('counter', Int32, self.rec_counter)

        self.stt = rospy.Publisher('room', Int32, queue_size = 10)
        self.pub = rospy.Publisher('cmd_vel', Twist, queue_size = 10)
        self.cont = rospy.Publisher('counter', Int32, queue_size = 10)

    def rec_counter(self, data):
        self.count = data.data

    def actual(self,data):
        self.state = data.data        

    def callback(self, data):
        if(self.color):
            try:
                cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
            except CvBridgeError as e:
                print(e)
            hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)

            # green                
            lower = np.array([36,25,25]) 
            upper = np.array([86,255,255])
            mask = cv2.inRange(hsv, lower, upper) # mask = 0_3
            max_malueg = np.max(mask)

            # blue
            lower = np.array([90,50,50]) 
            upper = np.array([10,255,255])
            mask = cv2.inRange(hsv, lower, upper) # mask = 0_3
            max_malueb = np.max(mask)

            self.green = max_malueb < max_malueg
            if max_malueg > 0 or max_malueb > 0:
                self.color = False
            self.state = 1

        if (self.state < 0):
            self.vel.angular.z = 0.5
            try:
                self.id = data.detections[0].results[0].id
                self.x = data.detections[0].bbox.center.x
            except:
                self.id = 0
                pass
            if self.id == 2 and self.green: # bicycle
                self.angular.z = 0
                self.state = -x+1
                self.count += 1

            if self.id == 9 and not self.green: # boat
                self.angular.z = 0
                self.state = -x+1
                self.count += 1
            self.pub.publish(self.vel)
            self.stt.publish(self.state)

def main(args):
    rospy.init_node('object_detector', anonymous=True)
    od = object_detector()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")

if __name__ == '__main__':
    main(sys.argv)