#!/usr/bin/env python
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal

class Navigate:
    def __init__(self):
        self.detect_sub = rospy.Subscriber("room", Int32, self.movebase_client)
        
        self.stt = rospy.Publisher('room', Int32, queue_size = 10)
        self.pub = rospy.Publisher('cmd_vel', Twist, queue_size = 10)

    def movebase_client(data):

        x = data.data
        client = actionlib.SimpleActionClient('move_base',MoveBaseAction)
        client.wait_for_server()

        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()

        # Room 1
        if x==1:
            goal.target_pose.pose.position.x = -4.169728
            goal.target_pose.pose.position.y = 2.491955
            goal.target_pose.pose.orientation.z = 0.0
            goal.target_pose.pose.orientation.w = 1.0

        elif x==2:
            goal.target_pose.pose.position.x = -3.351393
            goal.target_pose.pose.position.y = 1.610208
            goal.target_pose.pose.orientation.z = 0.0
            goal.target_pose.pose.orientation.w = 1.0  

        # Room 2
        elif x==3:
            goal.target_pose.pose.position.x = -3.162327
            goal.target_pose.pose.position.y = -0.167695
            goal.target_pose.pose.orientation.z = 0.0
            goal.target_pose.pose.orientation.w = 1.0 

        else: x == 4:
            goal.target_pose.pose.position.x = -3.211440
            goal.target_pose.pose.position.y = 0.307643
            goal.target_pose.pose.orientation.z = 0.0
            goal.target_pose.pose.orientation.w = 1.0
       
        # Room 3
        elif x==5:
            goal.target_pose.pose.position.x = 2.780070
            goal.target_pose.pose.position.y = 2.536815
            goal.target_pose.pose.orientation.z = 0.0
            goal.target_pose.pose.orientation.w = 1.0

        elif x==6:
            goal.target_pose.pose.position.x = 3.703107
            goal.target_pose.pose.position.y = 2.570476
            goal.target_pose.pose.orientation.z = 0.0
            goal.target_pose.pose.orientation.w = 1.0  

        # Room 4
        elif x==7:
            goal.target_pose.pose.position.x = 3.772203
            goal.target_pose.pose.position.y = -0.130144
            goal.target_pose.pose.orientation.z = 0.0
            goal.target_pose.pose.orientation.w = 1.0 

        elif x==8:
            goal.target_pose.pose.position.x = 2.703218
            goal.target_pose.pose.position.y = -0.102143
            goal.target_pose.pose.orientation.z = 0.0
            goal.target_pose.pose.orientation.w = 1.0

        
        client.send_goal(goal)
        wait = client.wait_for_result()
        if not wait:
            rospy.logerr("Action server not available!")
            rospy.signal_shutdown("Action server not available!")
        else:
            return client.get_result()
        self.stt.publish(-x)

def main(args):
    rospy.init_node('navigation', anonymous=True)
    Navigate()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")

if __name__ == '__main__':
    main(sys.argv)